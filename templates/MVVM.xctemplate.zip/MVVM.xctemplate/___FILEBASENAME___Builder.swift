//
//  ___FILEBASENAME___Builder.swift
//  ___TARGETNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit

final class ___VARIABLE_productName___Builder {
    public static func build() -> UIViewController {
        let router = ___VARIABLE_productName___Router()
        let viewModel = ___VARIABLE_productName___ViewModel(router: router)
        let viewController = ___VARIABLE_productName___ViewController(viewModel: viewModel)
        router.inject(viewController: viewController)
        return viewController
    }
}
