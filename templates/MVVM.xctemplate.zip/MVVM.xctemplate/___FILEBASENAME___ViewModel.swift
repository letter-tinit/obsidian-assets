//
//  ___FILEBASENAME___ViewModel.swift
//  ___TARGETNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Combine

final class ___VARIABLE_productName___ViewModel: ViewModel {
    private let router: ___VARIABLE_productName___Router

    init(router: ___VARIABLE_productName___Router) {
        self.router = router
    }
}

// MARK: - ViewModelType
extension ___VARIABLE_productName___ViewModel: ViewModelType {
    struct Input {}
    struct Output {
        let screenName: AnyPublisher<String?, Never>
    }

    func transform(_ input: Input) -> Output {
        return Output(
            screenName: Just("___VARIABLE_productName___.title").eraseToAnyPublisher()
        )
    }
}

// MARK: - Private Helper
extension ___VARIABLE_productName___ViewModel {}
