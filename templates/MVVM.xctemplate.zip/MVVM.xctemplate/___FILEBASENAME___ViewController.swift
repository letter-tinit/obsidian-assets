//
//  ___FILEBASENAME___ViewController.swift
//  ___TARGETNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit
import Styleguide

final class ___VARIABLE_productName___ViewController: BaseViewController {
    private let viewModel: ___VARIABLE_productName___ViewModel

    init(viewModel: ___VARIABLE_productName___ViewModel) {
        self.viewModel = viewModel
        super.init()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        binding()
    }

    // MARK: - Private

    private func setupView() {
        addBackgroundGradient()
    }
}

// MARK: - Binding
extension ___VARIABLE_productName___ViewController {
    private func binding() {
        let input = ___VARIABLE_productName___ViewModel.Input()
        let output = viewModel.transform(input)

        output
            .screenName
            .assignWithObject(to: \.title, on: self)
            .store(in: self)
    }
}
