//
//  CoffeeOrderListScreen.swift
//  HotCoffee
//
//  Created by Mohammad Azam on 8/14/23.
//

import SwiftUI

struct CoffeeOrderListScreen: View {
    
    @Environment(\.httpClient) private var httpClient
    
    // @Environment(\.store) private var store
    
    @State private var isPresented: Bool = false
    @State private var orders: [CoffeeOrder] = []
    
    private func loadOrders() async {
        
        do {
            let resource = Resource(url: APIs.orders.url, modelType: [CoffeeOrder].self)
            orders = try await httpClient.load(resource)
        } catch {
            print(error)
        }
        
    }
    
    var body: some View {
        List(orders) { order in
            NavigationLink(value: order) {
                Text(order.name)
            }
        }
        .navigationDestination(for: CoffeeOrder.self, destination: { coffeeOrder in
            CoffeeDetailScreen(coffeeOrder: coffeeOrder)
        })
        .task {
            await loadOrders()
        }.navigationTitle("Orders")
            .toolbar(content: {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Add Order") {
                        isPresented = true
                    }
                }
            })
            .sheet(isPresented: $isPresented, content: {
                
                AddCoffeeOrderScreen(orders: $orders)
                
            })
    }
}

#Preview {
    NavigationStack {
        CoffeeOrderListScreen()
            .environment(\.httpClient, HTTPClient())
    }
}
